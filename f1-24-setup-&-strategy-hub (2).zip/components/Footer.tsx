
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-f1-light-dark py-8 mt-12 border-t border-gray-700">
      <div className="container mx-auto px-4 text-center">
        <p className="text-f1-text-darker text-sm">
          &copy; {new Date().getFullYear()} F1 Setup & Strategy Hub. All setups and strategies are AI-generated suggestions.
        </p>
        <p className="text-f1-text-darker text-xs mt-1">
          Always test configurations before relying on them in important races. Not affiliated with Codemasters or Formula 1&reg;.
        </p>
         <p className="text-f1-text-darker text-xs mt-2">
          Powered by <a href="https://deepmind.google/technologies/gemini/" target="_blank" rel="noopener noreferrer" className="text-f1-accent-blue hover:underline">Google Gemini</a>
        </p>
      </div>
    </footer>
  );
};

export default Footer;
