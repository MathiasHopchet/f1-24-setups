
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="bg-f1-light-dark py-6 shadow-lg">
      <div className="container mx-auto px-4 text-center">
        <h1 className="text-4xl font-bold text-f1-accent-red tracking-tight">
          F1<span className="text-f1-accent-blue">24</span> Setup & Strategy Hub
        </h1>
        <p className="text-f1-text-darker mt-1">Powered by AI for peak performance</p>
      </div>
    </header>
  );
};

export default Header;
