import React from 'react';
import { Option } from '../types.ts';

interface SelectInputProps {
  label: string;
  id: string;
  value: string;
  options: Option[];
  onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void;
  disabled?: boolean;
  className?: string;
}

const SelectInput: React.FC<SelectInputProps> = ({ label, id, value, options, onChange, disabled = false, className = '' }) => {
  return (
    <div className={`mb-4 ${className}`}>
      <label htmlFor={id} className="block text-sm font-medium text-f1-text-darker mb-1">
        {label}
      </label>
      <select
        id={id}
        name={id}
        value={value}
        onChange={onChange}
        disabled={disabled}
        className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-f1-light-dark border-gray-600 focus:outline-none focus:ring-f1-accent-blue focus:border-f1-accent-blue sm:text-sm rounded-md text-f1-text disabled:opacity-50"
      >
        {options.map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
    </div>
  );
};

export default SelectInput;