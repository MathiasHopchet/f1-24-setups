
import React, { useState } from 'react';
import { CarSetup } from '../types.ts';

interface SetupCardProps {
  setup: CarSetup;
  trackImageUrl?: string;
  trackName?: string;
  trackGuideText: string | null; // Changed from setup.trackGuide
}

type TabKey = 'details' | 'guide';

const SetupDetailItem: React.FC<{ label: string; value: string | number | undefined }> = ({ label, value }) => (
  <div className="flex justify-between py-1.5 px-2 even:bg-gray-700/30 odd:bg-transparent rounded-sm">
    <span className="text-f1-text-darker text-sm">{label}:</span>
    <span className="font-semibold text-f1-text text-sm">{String(value ?? 'N/A')}</span>
  </div>
);

const SetupSection: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
    <div className="mb-4">
        <h4 className="text-lg font-semibold text-f1-accent-blue mb-2 border-b border-f1-accent-blue/50 pb-1">{title}</h4>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-0">
            {children}
        </div>
    </div>
);


const SetupCard: React.FC<SetupCardProps> = ({ setup, trackImageUrl, trackName, trackGuideText }) => {
  const [activeTab, setActiveTab] = useState<TabKey>('details');

  // If there's a track guide, default to the guide tab, otherwise details.
  // This can be adjusted based on preference. Or, only switch if details are not primary.
  // For now, let's keep details as default unless there's ONLY a guide (which shouldn't happen here).
  // useEffect(() => {
  //   if (trackGuideText && !activeTabWasSet) { // Ensure this only runs once or when trackGuideText becomes available
  //     setActiveTab('guide');
  //     // setActiveTabWasSet(true); // you'd need a state for this
  //   } else if (!trackGuideText) {
  //     setActiveTab('details');
  //   }
  // }, [trackGuideText]);


  return (
    <div className="bg-f1-light-dark shadow-xl rounded-lg my-6 animate-fadeIn overflow-hidden">
      {trackImageUrl && (
        <img
          src={trackImageUrl}
          alt={`${trackName || setup.track} Layout`}
          className="w-full h-72 object-contain object-center rounded-t-lg bg-f1-dark"
          onError={(e) => (e.currentTarget.style.display = 'none')}
        />
      )}
      <div className="p-6">
        <h3 className="text-2xl font-bold text-f1-accent-red mb-1">{setup.setupName || "Car Setup"}</h3>
        <p className="text-sm text-f1-text-darker mb-4">Track: {trackName || setup.track || 'N/A'} | Condition: {setup.condition || 'N/A'}</p>

        {/* Tab Navigation */}
        <div className="flex border-b border-gray-700 mb-6">
          <button
            onClick={() => setActiveTab('details')}
            className={`px-4 py-2 font-semibold text-sm transition-colors duration-150
                        ${activeTab === 'details' 
                          ? 'border-b-2 border-f1-accent-red text-f1-accent-red' 
                          : 'text-f1-text-darker hover:text-f1-text border-b-2 border-transparent'}`}
            aria-current={activeTab === 'details' ? 'page' : undefined}
          >
            Setup Details
          </button>
          {trackGuideText && ( // Condition changed to trackGuideText prop
            <button
              onClick={() => setActiveTab('guide')}
              className={`px-4 py-2 font-semibold text-sm transition-colors duration-150
                          ${activeTab === 'guide' 
                            ? 'border-b-2 border-f1-accent-red text-f1-accent-red' 
                            : 'text-f1-text-darker hover:text-f1-text border-b-2 border-transparent'}`}
              aria-current={activeTab === 'guide' ? 'page' : undefined}
            >
              Track Guide
            </button>
          )}
        </div>

        {/* Tab Content */}
        {activeTab === 'details' && (
          <div className="space-y-4">
            <SetupSection title="Aerodynamics">
              <SetupDetailItem label="Front Wing" value={setup.aerodynamics?.frontWing} />
              <SetupDetailItem label="Rear Wing" value={setup.aerodynamics?.rearWing} />
            </SetupSection>

            <SetupSection title="Transmission">
              <SetupDetailItem label="Diff On-Throttle" value={setup.transmission?.differentialAdjustmentOnThrottle} />
              <SetupDetailItem label="Diff Off-Throttle" value={setup.transmission?.differentialAdjustmentOffThrottle} />
            </SetupSection>

            <SetupSection title="Suspension Geometry">
              <SetupDetailItem label="Front Camber" value={setup.suspensionGeometry?.frontCamber} />
              <SetupDetailItem label="Rear Camber" value={setup.suspensionGeometry?.rearCamber} />
              <SetupDetailItem label="Front Toe" value={setup.suspensionGeometry?.frontToe} />
              <SetupDetailItem label="Rear Toe" value={setup.suspensionGeometry?.rearToe} />
            </SetupSection>

            <SetupSection title="Suspension">
              <SetupDetailItem label="Front Suspension" value={setup.suspension?.frontSuspension} />
              <SetupDetailItem label="Rear Suspension" value={setup.suspension?.rearSuspension} />
              <SetupDetailItem label="Front Anti-Roll Bar" value={setup.suspension?.frontAntiRollBar} />
              <SetupDetailItem label="Rear Anti-Roll Bar" value={setup.suspension?.rearAntiRollBar} />
              <SetupDetailItem label="Front Ride Height" value={setup.suspension?.frontRideHeight} />
              <SetupDetailItem label="Rear Ride Height" value={setup.suspension?.rearRideHeight} />
            </SetupSection>

            <SetupSection title="Brakes">
              <SetupDetailItem label="Brake Pressure" value={setup.brakes?.brakePressure} />
              <SetupDetailItem label="Front Brake Bias" value={setup.brakes?.frontBrakeBias} />
            </SetupSection>

            <SetupSection title="Tyres">
              <SetupDetailItem label="Front Right Pressure" value={setup.tyres?.frontRightTyrePressure} />
              <SetupDetailItem label="Front Left Pressure" value={setup.tyres?.frontLeftTyrePressure} />
              <SetupDetailItem label="Rear Right Pressure" value={setup.tyres?.rearRightTyrePressure} />
              <SetupDetailItem label="Rear Left Pressure" value={setup.tyres?.rearLeftTyrePressure} />
            </SetupSection>

            {setup.notes && (
                 <div className="mt-6 pt-4 border-t border-gray-700">
                    <h4 className="text-lg font-semibold text-f1-accent-blue mb-2">Notes</h4>
                    <p className="text-f1-text-darker whitespace-pre-wrap col-span-1 sm:col-span-2 text-sm">{setup.notes}</p>
                </div>
            )}
          </div>
        )}

        {activeTab === 'guide' && trackGuideText && ( // Condition changed to trackGuideText prop
          <div className="bg-gray-800/50 p-4 rounded-md ring-1 ring-gray-700">
            <h4 className="text-xl font-semibold text-f1-accent-blue mb-3">Track Guide: {trackName || setup.track}</h4>
            <p className="text-f1-text-darker whitespace-pre-wrap leading-relaxed text-sm">{trackGuideText}</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default SetupCard;
