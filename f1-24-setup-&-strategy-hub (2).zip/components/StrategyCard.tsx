
import React, { useState } from 'react';
import { RaceStrategy, StrategyStint } from '../types.ts';

interface StrategyCardProps {
  strategy: RaceStrategy;
  trackImageUrl?: string;
  trackName?: string;
  trackGuideText: string | null; // Changed from strategy.trackGuide
}

type TabKey = 'details' | 'guide';

const TyreChip: React.FC<{ tyre: string }> = ({ tyre }) => {
  let bgColor = 'bg-gray-500';
  let textColor = 'text-white';
  if (tyre) {
    switch (tyre.toLowerCase()) {
      case 'soft': bgColor = 'bg-red-500'; break;
      case 'medium': bgColor = 'bg-yellow-400'; textColor = 'text-black'; break;
      case 'hard': bgColor = 'bg-gray-200'; textColor = 'text-black'; break;
      case 'intermediate': case 'inter': bgColor = 'bg-green-500'; break;
      case 'wet': bgColor = 'bg-blue-500'; break;
    }
  }
  return <span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${bgColor} ${textColor}`}>{tyre || 'N/A'}</span>;
};

const StrategyCard: React.FC<StrategyCardProps> = ({ strategy, trackImageUrl, trackName, trackGuideText }) => {
  const [activeTab, setActiveTab] = useState<TabKey>('details');

  return (
    <div className="bg-f1-light-dark shadow-xl rounded-lg my-6 animate-fadeIn overflow-hidden">
      {trackImageUrl && (
        <img
          src={trackImageUrl}
          alt={`${trackName || strategy.track} Layout`}
          className="w-full h-72 object-contain object-center rounded-t-lg bg-f1-dark"
          onError={(e) => (e.currentTarget.style.display = 'none')}
        />
      )}
      <div className="p-6">
        <h3 className="text-2xl font-bold text-f1-accent-red mb-1">{strategy.strategyName || "Race Strategy"}</h3>
        <p className="text-sm text-f1-text-darker mb-4">
          Track: {trackName || strategy.track} | Race Length: {strategy.raceLength} | Weather: {strategy.weather}
        </p>

        {/* Tab Navigation */}
        <div className="flex border-b border-gray-700 mb-6">
          <button
            onClick={() => setActiveTab('details')}
            className={`px-4 py-2 font-semibold text-sm transition-colors duration-150
                        ${activeTab === 'details' 
                          ? 'border-b-2 border-f1-accent-red text-f1-accent-red' 
                          : 'text-f1-text-darker hover:text-f1-text border-b-2 border-transparent'}`}
            aria-current={activeTab === 'details' ? 'page' : undefined}
          >
            Strategy Details
          </button>
          {trackGuideText && ( // Condition changed to trackGuideText prop
            <button
              onClick={() => setActiveTab('guide')}
              className={`px-4 py-2 font-semibold text-sm transition-colors duration-150
                          ${activeTab === 'guide' 
                            ? 'border-b-2 border-f1-accent-red text-f1-accent-red' 
                            : 'text-f1-text-darker hover:text-f1-text border-b-2 border-transparent'}`}
              aria-current={activeTab === 'guide' ? 'page' : undefined}
            >
              Track Guide
            </button>
          )}
        </div>

        {/* Tab Content */}
        {activeTab === 'details' && (
          <>
            <div className="mb-4">
              <h4 className="text-lg font-semibold text-f1-accent-blue mb-3 border-b border-f1-accent-blue/50 pb-1">Stints</h4>
              {strategy.stints && strategy.stints.length > 0 ? (
                <ul className="space-y-3">
                  {strategy.stints.map((stint: StrategyStint, index: number) => (
                    <li key={index} className="p-3 bg-gray-700/30 rounded-md flex flex-col sm:flex-row justify-between items-start sm:items-center">
                      <div className="flex items-center mb-2 sm:mb-0">
                        <span className="font-semibold text-f1-text mr-3">Stint {index + 1}:</span>
                        <TyreChip tyre={stint.tyre} />
                      </div>
                      <div className="text-sm text-f1-text-darker">
                        <p>Laps: {stint.laps || 'N/A'}</p>
                        {stint.pitWindow && <p>Pit Window: {stint.pitWindow}</p>}
                      </div>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-f1-text-darker text-sm">No stints defined for this strategy.</p>
              )}
            </div>

            {strategy.notes && (
              <div className="mt-6 pt-4 border-t border-gray-700">
                <h4 className="text-lg font-semibold text-f1-accent-blue mb-2">Notes</h4>
                <p className="text-f1-text-darker whitespace-pre-wrap text-sm">{strategy.notes}</p>
              </div>
            )}
          </>
        )}

        {activeTab === 'guide' && trackGuideText && ( // Condition changed to trackGuideText prop
          <div className="bg-gray-800/50 p-4 rounded-md ring-1 ring-gray-700">
            <h4 className="text-xl font-semibold text-f1-accent-blue mb-3">Track Guide: {trackName || strategy.track}</h4>
            <p className="text-f1-text-darker whitespace-pre-wrap leading-relaxed text-sm">{trackGuideText}</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default StrategyCard;
