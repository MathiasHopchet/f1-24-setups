import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import type { Handler, HandlerEvent } from "@netlify/functions";
// Assuming your types.ts and constants.ts are two levels up from netlify/functions/
import { QueryType, CarSetup, RaceStrategy, ApiError, TrackGuide, TrackGuideResponse } from '../../types';
import { API_MODEL_TEXT } from '../../constants';

const GEMINI_API_KEY = process.env.API_KEY;

// --- Helper functions (copied and adapted from your original GeminiService.ts) ---
function buildTrackGuidePrompt(track: string): string {
  return `
You are an F1 24 expert. Provide an extremely detailed corner-by-corner guide specifically for the ${track} circuit as it appears in the F1 24 game.

For EACH significant corner or section, include the following:
1.  Corner Name/Number: (e.g., Turn 1 - La Source)
2.  Optimal Racing Line: Describe the ideal path through the corner (e.g., "late apex", "use all the kerb on exit").
3.  Braking Point & Distance: Be specific. (e.g., "Brake hard just before the 100m board, approximately 110m before apex", "Light dab on the brakes for 20 meters", "Braking zone starts at the end of the blue marshall post, hold for 60m").
4.  Steering Input: Describe how to steer (e.g., "Smooth, progressive turn-in", "Sharp, aggressive flick to initiate rotation then ease off", "Hold a consistent steering angle through the long apex, gradually unwinding on exit").
5.  Gear Suggestion: The typical gear for an F1 car in F1 24 (e.g., "3rd gear").
6.  Kerb Usage: Specify which kerbs are safe/beneficial to use and which to avoid (e.g., "Use the inside kerb aggressively but avoid unsettling the car", "Avoid the high sausage kerb on exit as it can lead to a spin").
7.  Extra Tips / Common Pitfalls: Any other crucial advice for this corner (e.g., "Watch for track limits on exit", "Easy to lock up here if too aggressive on brakes", "Crucial for a good run onto the next straight, prioritize exit speed", "Be patient on the throttle to avoid wheelspin").

Structure your response ONLY as a single JSON object:
{
  "track": "${track}",
  "trackGuide": "A comprehensive string containing the corner-by-corner guide as described above. Use clear formatting like newlines and headings for each corner to make it readable. Example for one corner: 'Turn 1 - Example Corner: \\nRacing Line: Aim for a wide entry... \\nBraking: Brake at the 100m board for about 70m... \\nSteering: Sharp turn-in... \\nGear: 2nd gear... \\nKerbs: Use the inside kerb... \\nTips: Crucial for a good start...'"
}
If you cannot provide a guide for the specific track, respond with a JSON object: {"error": "Could not generate track guide for ${track}."}
`;
}


function buildSetupPrompt(track: string, condition: string, customRequests: string): string {
  return `
You are an F1 24 expert. Provide a detailed F1 24 car setup for the ${track} circuit in ${condition} conditions.
${customRequests ? `Consider these specific requests: ${customRequests}.` : ''}
The setup should include specific values for:
- Aerodynamics (Front Wing, Rear Wing)
- Transmission (Differential Adjustment On Throttle, Differential Adjustment Off Throttle)
- Suspension Geometry (Front Camber, Rear Camber, Front Toe, Rear Toe)
- Suspension (Front Suspension, Rear Suspension, Front Anti-Roll Bar, Rear Anti-Roll Bar, Front Ride Height, Rear Ride Height)
- Brakes (Brake Pressure, Front Brake Bias)
- Tyres (Front Right Tyre Pressure, Front Left Tyre Pressure, Rear Right Tyre Pressure, Rear Left TyrePressure)
- Optional: A brief "notes" field for any specific advice regarding this setup.

Respond ONLY with a single JSON object matching this structure:
{
  "track": "${track}",
  "condition": "${condition}",
  "setupName": "string (e.g., ${condition} Race Setup for ${track})",
  "aerodynamics": { "frontWing": "integer (1-50)", "rearWing": "integer (1-50)" },
  "transmission": { "differentialAdjustmentOnThrottle": "integer % (50-100)", "differentialAdjustmentOffThrottle": "integer % (50-100)" },
  "suspensionGeometry": { "frontCamber": "decimal degrees (e.g., -2.5)", "rearCamber": "decimal degrees (e.g., -1.0)", "frontToe": "decimal degrees (e.g., 0.05)", "rearToe": "decimal degrees (e.g., 0.20)" },
  "suspension": { "frontSuspension": "integer (1-41)", "rearSuspension": "integer (1-41)", "frontAntiRollBar": "integer (1-21)", "rearAntiRollBar": "integer (1-21)", "frontRideHeight": "integer (e.g., 30-50 for low, 50-70 for high, provide exact values based on F1 24 scale)", "rearRideHeight": "integer (e.g., 50-80 for low, 70-90 for high, provide exact values based on F1 24 scale)" },
  "brakes": { "brakePressure": "integer % (80-100)", "frontBrakeBias": "integer % (50-70)" },
  "tyres": { "frontRightTyrePressure": "decimal psi (e.g., 22.5)", "frontLeftTyrePressure": "decimal psi (e.g., 22.5)", "rearRightTyrePressure": "decimal psi (e.g., 20.5)", "rearLeftTyrePressure": "decimal psi (e.g., 20.5)" },
  "notes": "string (optional)"
}
Ensure all values are appropriate for F1 24 and the given conditions.
If you cannot provide a setup for the specific request, respond with a JSON object: {"error": "Could not generate setup for the given parameters."}
`;
}

function buildStrategyPrompt(track: string, raceLength: string, weather: string, customRequests: string): string {
  return `
You are an F1 24 expert strategist. Suggest a race strategy for F1 24 at ${track} for a ${raceLength} race, considering ${weather} conditions.
${customRequests ? `Consider these specific requests: ${customRequests}.` : ''}
The strategy should include:
- Strategy Name (e.g., Aggressive One-Stop)
- Stints: An array of stints, each specifying tyre compound (Soft, Medium, Hard, Intermediate, Wet), lap range (e.g., "1-15"), and an optional pit window (e.g., "Lap 14-16").
- Optional: A brief "notes" field for key considerations, alternative options, or advice.

Respond ONLY with a single JSON object matching this structure:
{
  "track": "${track}",
  "raceLength": "${raceLength}",
  "weather": "${weather}",
  "strategyName": "string (e.g., Flexible One-Stopper)",
  "stints": [
    { "tyre": "string (Soft/Medium/Hard/Inter/Wet)", "laps": "string (e.g., 1-20)", "pitWindow": "string (optional, e.g., Laps 18-20)" }
  ],
  "notes": "string (optional)"
}
Ensure the strategy is logical for F1 24 and the given parameters.
If you cannot provide a strategy, respond with a JSON object: {"error": "Could not generate strategy for the given parameters."}
`;
}

const parseGeminiResponse = <T,>(responseText: string): T | ApiError => {
  let jsonStr = responseText.trim();
  const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
  const match = jsonStr.match(fenceRegex);
  if (match && match[2]) {
    jsonStr = match[2].trim();
  }
  try {
    return JSON.parse(jsonStr) as T;
  } catch (e) {
    console.error("Failed to parse JSON response in function:", e, "Raw response:", responseText);
    return { error: "Failed to parse AI response in function. The AI may have returned an unexpected format." };
  }
};
// --- End of Helper functions ---


const handler: Handler = async (event: HandlerEvent) => {
  if (!GEMINI_API_KEY) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "API Key not configured on server." }),
    };
  }
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: JSON.stringify({error: "Method Not Allowed"}) };
  }

  const ai = new GoogleGenAI({ apiKey: GEMINI_API_KEY });

  try {
    const body = JSON.parse(event.body || "{}");
    const { operation, params } = body;

    let prompt: string;
    let genAIResponse: GenerateContentResponse;
    let responseText: string;

    if (operation === 'trackGuide') {
      if (!params || !params.track) {
        return { statusCode: 400, body: JSON.stringify({ error: "Missing track parameter for trackGuide operation."}) };
      }
      prompt = buildTrackGuidePrompt(params.track);
      genAIResponse = await ai.models.generateContent({
        model: API_MODEL_TEXT,
        contents: prompt,
        config: { responseMimeType: "application/json", temperature: 0.3 },
      });
      responseText = genAIResponse.text;
      if (!responseText) {
          return { statusCode: 500, body: JSON.stringify({ error: "Received an empty response from the AI for the track guide." })};
      }
      return { statusCode: 200, headers: {"Content-Type": "application/json"}, body: JSON.stringify(parseGeminiResponse<TrackGuide>(responseText)) };
    
    } else if (operation === 'f1Data') {
      if (!params || !params.queryType || !params.track || !params.weather) {
         return { statusCode: 400, body: JSON.stringify({ error: "Missing required parameters for f1Data operation."}) };
      }
      const { queryType, track, weather, raceLength, customRequests } = params;
      if (queryType === QueryType.SETUP) {
        prompt = buildSetupPrompt(track, weather, customRequests);
      } else {
         if (!raceLength) {
            return { statusCode: 400, body: JSON.stringify({ error: "Missing raceLength for strategy operation."}) };
         }
        prompt = buildStrategyPrompt(track, raceLength, weather, customRequests);
      }
      genAIResponse = await ai.models.generateContent({
        model: API_MODEL_TEXT,
        contents: prompt,
        config: { responseMimeType: "application/json", temperature: 0.5 },
      });
      responseText = genAIResponse.text;
      if (!responseText) {
          return { statusCode: 500, body: JSON.stringify({ error: "Received an empty response from the AI for F1 data." })};
      }
      let parsedResponse;
      if (queryType === QueryType.SETUP) {
        parsedResponse = parseGeminiResponse<CarSetup>(responseText);
      } else {
        parsedResponse = parseGeminiResponse<RaceStrategy>(responseText);
      }
      return { statusCode: 200, headers: {"Content-Type": "application/json"}, body: JSON.stringify(parsedResponse) };

    } else {
      return { statusCode: 400, body: JSON.stringify({ error: "Invalid operation specified." }) };
    }

  } catch (error: any) {
    console.error("Error in Netlify function (gemini.ts):", error);
    const message = error.message || "An unknown server error occurred.";
    if (error.toString().includes("API_KEY_INVALID")) { // Check for specific error if possible
        return { statusCode: 401, body: JSON.stringify({ error: "Invalid API Key configured on server." }) };
    }
    return {
      statusCode: 500,
      body: JSON.stringify({ error: `Server error in Netlify function: ${message}` }),
    };
  }
};

export { handler };
