import { QueryType, CarSetup, RaceStrategy, ApiResponse, ApiError, TrackGuide, TrackGuideResponse } from '../types';

// The path to your Netlify Function
const FUNCTION_PATH = '/.netlify/functions/gemini';

export const fetchTrackGuideData = async (track: string): Promise<TrackGuideResponse> => {
  try {
    const response = await fetch(FUNCTION_PATH, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ 
        operation: 'trackGuide', 
        params: { track } 
      }),
    });

    const responseData = await response.json();
    if (!response.ok) {
      // Use error from function response if available, otherwise a generic one
      return { error: responseData.error || `Failed to fetch track guide: Server responded with ${response.status}` };
    }
    return responseData as TrackGuideResponse;
  } catch (error: any) {
    console.error("Client-side error fetching track guide:", error);
    return { error: `Network error or invalid response when fetching track guide: ${error.message}` };
  }
};

export const fetchF1Data = async (
  queryType: QueryType,
  track: string,
  weather: string,
  raceLength: string, // Only for strategy
  customRequests: string
): Promise<ApiResponse> => {
  try {
    const response = await fetch(FUNCTION_PATH, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        operation: 'f1Data',
        params: { queryType, track, weather, raceLength, customRequests },
      }),
    });

    const responseData = await response.json();
    if (!response.ok) {
        // Use error from function response if available, otherwise a generic one
      return { error: responseData.error || `Failed to fetch F1 data: Server responded with ${response.status}` };
    }
    return responseData as ApiResponse;
  } catch (error: any) {
    console.error("Client-side error fetching F1 data:", error);
    return { error: `Network error or invalid response when fetching F1 data: ${error.message}` };
  }
};
